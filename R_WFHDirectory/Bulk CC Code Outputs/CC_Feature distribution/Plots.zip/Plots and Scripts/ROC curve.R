#Install and load packages
install.packages("ROCR")

library(ROCR)
library(dplyr)

#Set working directory
setwd("//userfs/jps558/w2k/Desktop/R_WorkingDirectory") 


#Set column names
pyCCcol_names = c("Chr",	"Start",	"End",	"Center",	"Experiment Insertions",	"Background insertions",	"Reference Insertions",	"pvalue Reference",	"pvalue Background",	"Fraction Experiment",	"TPH Experiment",	"Fraction background",	"TPH background",	"TPH background subtracted",	"pvalue_adj Reference", "Number of Overlaps with ChIP-Seq Peaks")

##Read data
#Variables named <Window '-a'><Window'-b'>
ESR1_pyCC_2_Andy_q = read.table("results/1kbp_A_peak_data_ER_WT2.bed_B_Andy_ChIP_q0.05_peaksNP.bed", header = TRUE, sep = "\t", col.names = pyCCcol_names)

ESR1_pyCC_2_Encode2_q = read.table("results/1kbp_A_peak_data_ER_WT2.bed_B_Encode_ER_rep2_ChIP_q0.05_peaksNP.bed", header = TRUE, sep = "\t", col.names = pyCCcol_names)

ESR1_pyCC_4_Andy_q = read.table("results/1kbp_A_peak_data_ER_WT4.bed_B_Andy_ChIP_q0.05_peaksNP.bed", header = TRUE, sep = "\t", col.names = pyCCcol_names)

#Change overlap values >0 to 1
ESR1_pyCC_2_Andy_q <- ESR1_pyCC_2_Andy_q %>%
  mutate(Number.of.Overlaps.with.ChIP.Seq.Peaks = ifelse(Number.of.Overlaps.with.ChIP.Seq.Peaks > 0, 1, Number.of.Overlaps.with.ChIP.Seq.Peaks))

ESR1_pyCC_2_Encode2_q <- ESR1_pyCC_2_Encode2_q %>%
  mutate(Number.of.Overlaps.with.ChIP.Seq.Peaks = ifelse(Number.of.Overlaps.with.ChIP.Seq.Peaks > 0, 1, Number.of.Overlaps.with.ChIP.Seq.Peaks))

ESR1_pyCC_4_Andy_q <- ESR1_pyCC_4_Andy_q %>%
  mutate(Number.of.Overlaps.with.ChIP.Seq.Peaks = ifelse(Number.of.Overlaps.with.ChIP.Seq.Peaks > 0, 1, Number.of.Overlaps.with.ChIP.Seq.Peaks))


# View the updated dataframe
print(ESR1_pyCC_2_Andy_q)
print(ESR1_pyCC_2_Encode2_q)
print(ESR1_pyCC_4_Andy_q)

#Using ROCR
data("ROCR.simple")
#Create Prediciton object
#Cannot use pvalue, must use predicted probablility

pred2 <- prediction(predicted_probability, ESR1_pyCC_2_Andy_q$Number.of.Overlaps.with.ChIP.Seq.Peaks)

#Create ROC curve

ROC2 <- performance(pred2, measure = "tpr", x.measure = "fpr")

#plot
plot(ROC2, main = "ROC curve", col = "blue", , lwd=2,  xaxs="i", yaxs="i")

abline(a = 0, b = 1, col = "red", lty = 2)

#Calculate and print AUC
ROC2_auc <- performance(pred2, measure = "auc")
print(paste("AUC:", ROC2_auc@y.values[[1]]))
text(0.7, 0.2, paste("AUC = ", round(ROC2_auc@y.values[[1]], 2)), col = "black", cex = 1.5)





